from flask import Blueprint, render_template, request, redirect, url_for, session, flash

main = Blueprint('main', __name__)

# Dummy user database
users = {'admin': 'admin123', 'user': 'user123'}

@main.route("/")
def home():
    return render_template("index.html")

@main.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if users.get(username) == password:
            session["user"] = username
            return redirect(url_for("main.dashboard"))
        else:
            flash("Invalid credentials", "danger")
    return render_template("login.html")

@main.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect(url_for("main.login"))
    return render_template("dashboard.html", user=session["user"])

@main.route("/logout")
def logout():
    session.pop("user", None)
    return redirect(url_for("main.home"))
