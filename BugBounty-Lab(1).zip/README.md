# BugBounty-Lab

Modern-looking, intentionally vulnerable web app for Burp Suite training.

## Setup
```bash
pip install -r requirements.txt
python run.py
```

## Vulnerabilities to Train On
- Weak authentication
- Broken access control
- Insecure session handling
- XSS (coming soon)
- SQL Injection (coming soon)

## Use Burp Suite to:
- Intercept login requests
- Try brute-force attacks
- Test for session hijacking
